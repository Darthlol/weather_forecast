import json
import requests
from flask import Flask,request,render_template

API_KEY = "c4af31f736msh1344f3b7b69595ap1b0fa0jsnc0d37dc07831"
API_HOST = "weatherapi-com.p.rapidapi.com"
API_URL = "https://weatherapi-com.p.rapidapi.com/current.json"

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/predict_weather',methods=['POST'])
def predict_weather():
    if request.method == 'POST':
        q = request.form['location']
        url = API_URL
        querystring = {"q":q}
        headers = {
            "X-RapidAPI-Key": API_KEY,
            "X-RapidAPI-Host": API_HOST
        }
        try:
            response = requests.request("GET", url, headers=headers, params=querystring)
            json_data = json.loads(response.text)
            name = json_data['location']['name']
            region = json_data['location']['region']
            country = json_data['location']['country']
            lat = json_data['location']['lat']
            lon = json_data['location']['lon']
            tz_id = json_data['location']['tz_id']
            localtime = json_data['location']['localtime']
            last_updated = json_data['current']['last_updated']
            temp_c = json_data['current']['temp_c']
            temp_f = json_data['current']['temp_f']
            condition = json_data['current']['condition']['icon']
            wind = json_data['current']['wind_kph']
            wind_degree = json_data['current']['wind_degree']
            wind_dir = json_data['current']['wind_dir']
            pressure = json_data['current']['pressure_mb']
            precip = json_data['current']['precip_mm']
            humidity = json_data['current']['humidity']
            feelslike_c = json_data['current']['feelslike_c']
            feelslike_f = json_data['current']['feelslike_f']
            vis = json_data['current']['vis_km']
            uv = json_data['current']['uv']
            gust = json_data['current']['gust_kph']

            return render_template('home.html',name=name,region=region,country=country,lat=lat,lon=lon,tz_id=tz_id,
                                   localtime=localtime,last_updated=last_updated,temp_c=temp_c,temp_f=temp_f,
                                   condition=condition,wind=wind,wind_degree=wind_degree,
                                   wind_dir=wind_dir,pressure=pressure,precip=precip,humidity=humidity,
                                   feelslike_c=feelslike_c,feelslike_f=feelslike_f,vis=vis,uv=uv,gust=gust)

        except:
            return render_template('home.html', error='Введите корректное местоположение...')


if __name__ == '__main__':
    app.run()
